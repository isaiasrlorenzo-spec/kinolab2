KINO LAB - SÚPER KINO TV

index.html: versión independiente para abrir localmente en un navegador.
manifest.json + sw.js + icons/: versión PWA para instalar como app desde un sitio HTTPS.

Para usar la versión local:
1. Descarga y extrae el ZIP.
2. Abre index.html en Chrome o navegador compatible.
3. Los registros se guardan en almacenamiento local del navegador. Exporta respaldos.

Para instalar como aplicación PWA:
1. Publica la carpeta completa en un alojamiento HTTPS (por ejemplo, GitHub Pages o Netlify).
2. Abre el URL publicado en Chrome Android.
3. Menú ⋮ > Instalar (o Instalar y crear acceso directo) > Instalar.

No es posible instalar una PWA completa directamente desde el ZIP sin alojarla en HTTPS; el archivo HTML local sí se puede abrir y usar, aunque depende del navegador para persistencia.
